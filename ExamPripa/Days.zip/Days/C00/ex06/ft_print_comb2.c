/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: aankote <marvin@42.fr>                     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/08/27 14:21:17 by aankote           #+#    #+#             */
/*   Updated: 2022/08/27 16:18:34 by aankote          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putchar(char n)
{
	write(1, &n, 1);
}

void	ft_print_comb2(void)
{
	int	units;
	int	teens;

	units = -1;
	while (units++ <= 98)
	{
		teens = units + 1;
		while (teens <= 99)
		{
			ft_putchar(units / 10 + 48);
			ft_putchar(units % 10 + 48);
			write(1, " ", 1);
			ft_putchar(teens / 10 + 48);
			ft_putchar(teens % 10 + 48);
			if (units != 98)
			{
				write(1, ", ", 2);
			}
			teens++;
		}
	}	
}
